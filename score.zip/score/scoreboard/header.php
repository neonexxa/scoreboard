<?php
echo "
<header id=\"header\">
				<h1><a href=\"index.php\">CYBERHAX</a></h1>
				<nav id=\"nav\">
					<ul>
						<li><a href=\"index.php\">Scoreboard</a></li>
						<li><a href=\"../score/\">Client Page</a></li>
					</ul>
				</nav>
			</header>
			";
?>