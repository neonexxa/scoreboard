<?php
$xley_con = 'haha x sambung ngan databased';

$mysql_host = 'localhost';
$mysql_user = 'root';
$mysql_pass = '';
$mysql_db = 'dabatase';


if (!@mysql_connect($mysql_host, $mysql_user, $mysql_pass)||!@mysql_select_db($mysql_db)){
        die ($xley_con);
}

$mysqli = new MySQLi($mysql_host,$mysql_user,$mysql_pass,$mysql_db);

?>

