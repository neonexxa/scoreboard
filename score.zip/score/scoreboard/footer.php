<?php
echo"<footer id=\"footer\">
				<div class=\"container\">
					<div class=\"row\">
						<div class=\"8u 12u$(medium)\">
							<ul class=\"copyright\">
								<li>&copy; Copyright CYBERHAX INC</li>
								<li>Design: <a href=\"\">TEMPLATED</a></li>
							</ul>
						</div>
						<div class=\"4u$ 12u$(medium)\">
							<ul class=\"icons\">
								<li>
									<a class=\"icon rounded fa-external-link\" href=\"http://cybersocks.org/\"><span class=\"label\"></span></a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</footer>";

?>