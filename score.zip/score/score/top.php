<div id="templatemo_top">
    	<div class="sitename_panel">
        	<div class="sitename"></div>
      </div>
        
        <div class="livechat_panel">
        	<a href="#popuping1"><img src="images/gambar.png" alt="livechat" width="200" height="120" /></a>
        </div>



        <div id="popuping1" class="overlaying">
    <div class="popuping">
        <h4><img src="images/gambar.png" width="150px" height="80px"/><br/>Cyberhax is a multilevel Programming and Networking club. It is build under CIS Dept of UTP to nuture the wellbeing and understanding of IT for the students.</h4>
        <a class="close" href="#">&times;</a>
        

            
        
    </div>
</div>
        
        <div class="freecall_panel">
          <div class="phoneno"><br/><h2>I-hack selection for UTP students</h2><br/><br/>2nd April 2016 ~ 12hours ~ Online</div>
        </div>
    <p>&nbsp;</p>
        
    </div>
