<?php

$db_name="dabatase";
$db_user="root";
$db_password="12haneefa34";
$db_server="localhost";

?>
