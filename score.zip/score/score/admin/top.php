<div id="templatemo_top">
    	<div class="sitename_panel">
        	<div class="sitename"></div>
      </div>
        
        <div class="livechat_panel">
        	<a href="#"><img src="images/utphax9.jpeg" alt="livechat" width="120" /></a>
        </div>
        
        <div class="freecall_panel">
          <div class="phoneno"><span>UTPHAX'14</span><br/><br/>14th-15th November 2014 - Chancellor Complex<br/><br/><span>s23eedbi<u>ADMIN</u>ff32fwaefw</span></div>
        </div>
    <p>&nbsp;</p>
        
    </div>