<?php
  $lnk = mysql_connect("localhost","root","") or die("Failed to connect");
  $db = mysql_select_db('your_database_name',$lnk) or die("DB is unreachable");
?>
